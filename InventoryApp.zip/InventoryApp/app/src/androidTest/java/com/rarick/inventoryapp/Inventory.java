package com.rarick.inventoryapp;

/**
 * Created by raric on 3/26/2017.
 */

public class Inventory {
}
